<?php
include 'of.php';
if(isset($_GET['deleteid'])){
$id=$_GET['deleteid'];
$sql="delete from rahul where id=$id";
$result=mysqli_query($con,$sql);
if($result){
    // echo "deleted successfully";
    header('location:hg.php');
}
else{
    die(mysqli_error($con));
}
}
